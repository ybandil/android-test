package com.example.project1;

public class Model {
    String Question;
    String oA;
    String oB;
    String ans;

    public Model(String question, String oA, String oB, String ans) {
        Question = question;
        this.oA = oA;
        this.oB = oB;
        this.ans = ans;
    }

    public String getQuestion() {
        return Question;
    }

    public void setQuestion(String question) {
        Question = question;
    }

    public String getoA() {
        return oA;
    }

    public void setoA(String oA) {
        this.oA = oA;
    }

    public String getoB() {
        return oB;
    }

    public void setoB(String oB) {
        this.oB = oB;
    }

    public String getAns() {
        return ans;
    }

    public void setAns(String ans) {
        this.ans = ans;
    }
}
