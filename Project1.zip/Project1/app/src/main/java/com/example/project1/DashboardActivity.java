package com.example.project1;

import static com.example.project1.MainActivity.list;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Collections;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {
    List<Model> allQuestionsList;
    Model model;
    int index=0;
    TextView card_question,option_true,option_false;
    CardView cardoA,cardoB;
    int yes=0;
    LinearLayout nextBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        Hook();
        allQuestionsList= list;
        Collections.shuffle(allQuestionsList);
        model=list.get(index);
        cardoA.setBackgroundColor(getResources().getColor(R.color.white));
        cardoB.setBackgroundColor(getResources().getColor(R.color.white));
        nextBtn.setClickable(false);
        setAllData();
    }

    private void setAllData() {
        card_question.setText(model.getQuestion());
        option_true.setText(model.getoA());
        option_false.setText(model.getoB());
    }

    private void Hook() {
        card_question=findViewById(R.id.card_question);
        option_true=findViewById(R.id.card_true);
        option_false=findViewById(R.id.card_false);

       // cardoA=findViewById(R.id.card_true);
       // cardoB=findViewById()
        nextBtn=findViewById(R.id.nextBtn);

    }
     public void Yes(CardView cardView){
        cardView.setBackgroundColor(getResources().getColor(R.color.green));
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                yes++;
                index++;
                model=list.get(index);
                setAllData();
            }
        });

    }
     public void No(CardView cardView){
         cardView.setBackgroundColor(getResources().getColor(R.color.green));
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //if(index<list.size()-1){
                    index++;
                    model=list.get(index);
                    setAllData();
                    resetColor();
               // } else{
                 //   Submit_Clear();
               // }
            }
        });

    }

    private void Submit_Clear() {
        Intent intent=new Intent(DashboardActivity.this,SecondActivity.class);
        startActivity(intent);

    }
    public void enableButton(){
        cardoA.setClickable(true);
        cardoB.setClickable(true);
    }
    public void disableButton(){
        cardoA.setClickable(false);
        cardoB.setClickable(false);
    }
    public void resetColor(){
        cardoA.setBackgroundColor(getResources().getColor(R.color.white));
        cardoB.setBackgroundColor(getResources().getColor(R.color.white));
    }

    public void OptionAClick(View view) {
        disableButton();
        nextBtn.setClickable(true);
        cardoA.setCardBackgroundColor(getResources().getColor(R.color.green));
        if (index < list.size() - 1) {
            Yes(cardoA);
        } else {
            Submit_Clear();
        }
    }
        public void OptionBClick(View view){
        disableButton();
            nextBtn.setClickable(true);
            cardoB.setCardBackgroundColor(getResources().getColor(R.color.green));
            if(index<list.size()-1){
               No(cardoB);
            }
            else{
                Submit_Clear();
            }
    }




}