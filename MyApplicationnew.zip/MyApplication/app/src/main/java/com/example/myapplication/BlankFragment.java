package com.example.myapplication;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;


public class BlankFragment extends Fragment {


    View view;
    TextView textName;
    Integer count;
    Button bb;
    public BlankFragment()
    {

    }
    public static ArrayList<String> l;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        view = inflater.inflate(R.layout.fragment_blank, container, false);
        textName =  view.findViewById(R.id.textName);
        bb  = view.findViewById(R.id.buttonacv);
        l = new ArrayList<>();
        Bundle data = getArguments();
        l = data.getStringArrayList("kl");
        textName.setText(l.get(0));
        /*if(l.get(0) == "yash")
        {
            count = 1;
        }*/
        bb.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {


                //replacefragment1(new BlankFragment2());
                //Intent intent = new Intent(MainActivity2.this, MainActivity.class);

                //startActivity(intent);

            }

        });
        return view;
    }
    /*private void replacefragment1(BlankFragment2 blankFragment2) {

        Fragment blankFragment3 = new BlankFragment2();
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction1 = fragmentManager.beginTransaction();
        Bundle data = new Bundle();
        data.putInt("ppp", 1);
        blankFragment2.setArguments(data);
        //getFragmentManager().
        fragmentTransaction1.replace(R.id.framel, blankFragment3, "findThisFragment").addToBackStack(null);
        fragmentTransaction1.commit();
    }*/
}