package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ResourceManagerInternal;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
//port android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "Main-activity";
    public static ArrayList<Model>list;
    List<Model> allQuestionsList;
    int yes=0;
    int index=0;
    int flag = 0;
    int check = 0 ;
    int currentIndex = 0;
    String name ;
    LinearLayout nextBtn;
    LinearLayout clearBtn;
    Controllerclass controllerclass;
    LinearLayout noBtn;
    LinearLayout yesBtn;
    Model model;
    TextView Text_question , Text_yesBtn,Text_noBtn, text_view;
    EditText editText;
    CardView card_yesBtn,card_noBtn;
    public static ArrayList <String> result;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Hooks();
        list=new ArrayList<>();
        controllerclass = new Controllerclass(this);


        if (savedInstanceState != null) {
            index = savedInstanceState.getInt("index");
            result = savedInstanceState.getStringArrayList("result");
            currentIndex = savedInstanceState.getInt("cindex");
            yes = savedInstanceState.getInt("yes");
            flag = savedInstanceState.getInt("flag");
            name = savedInstanceState.getString("text_view");

        }


        Log.d(TAG, "lAST QUESTION ID = " + index);

        Toast.makeText(MainActivity.this, "WELCOME",Toast.LENGTH_SHORT).show();
        Toast.makeText(MainActivity.this, "Main Acctivity"+getLifecycle().getCurrentState().toString(),Toast.LENGTH_SHORT).show();
        list.add(new Model("Do you have fever1?"));
        list.add(new Model("Do you have cough2?"));
        list.add(new Model("Do you have Cold3?"));
        list.add(new Model("Do you have fever4?"));
        list.add(new Model("Do you have fever5?"));
        list.add(new Model("Do you have fever6?"));
        list.add(new Model("Do you have fever7?"));
        clearBtn.setVisibility(View.INVISIBLE);
        result = new ArrayList<String>();
        Text_question = (TextView)findViewById(R.id.question);
        //Text_question.setText("mode");
        allQuestionsList= list;
        //Collections.shuffle(allQuestionsList);
         model=list.get(index);
        nextBtn.setEnabled(false);
        nextBtn.setBackgroundColor(Color.rgb(200, 200, 200));

        setAllData();

        //nextBtn.setClickable(false);
        yesBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //controllerclass.testcall();
                if(check == 0)
                {
                    check = 1;
                }
                else if(check == 1)
                {
                    noBtn.setBackgroundColor(getResources().getColor(R.color.purple_200));
                    result.remove(index-1);
                    index= index -1;

                }
                 nextBtn.setEnabled(true);

                nextBtn.setBackgroundColor(Color.rgb(50, 151, 202));

                name = editText.getText().toString();
                controllerclass.testcall(result,yes,index);
                 /*result.add("Yes");
                text_view.setText("Hello!"+" "+name);
                yesBtn.setBackgroundColor(getResources().getColor(R.color.teal_200));

                    yes = yes + 1;
                    index = index + 1;
                if(index == list.size()  )
                {
                    clearBtn.setVisibility(View.VISIBLE);
                }*/
                    //model=list.get(index);

            }
        });

        noBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nextBtn.setEnabled(true);
                if(check == 0)
                {
                    check = 1;
                }
                else if(check == 1)
                {
                    yesBtn.setBackgroundColor(getResources().getColor(R.color.purple_200));
                    result.remove(index-1);
                    index = index - 1;

                }
                nextBtn.setBackgroundColor(Color.rgb(50, 151, 202));
                name = editText.getText().toString();
                controllerclass.Nobtncall(result,index);
                /*text_view.setText("Hello!"+" "+name);
                noBtn.setBackgroundColor(getResources().getColor(R.color.teal_200));

                    result.add("No");
                    index++;
                if(index == list.size()  )
                {
                    clearBtn.setVisibility(View.VISIBLE);
                }*/
                   // model=list.get(index);
                    //setAllData();
                    //resetColor();

            }
        });


        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag = 1;
                name = editText.getText().toString();
                if(name.length() == 0)
                {
                    Toast.makeText(MainActivity.this, "Please Enter Your Name",Toast.LENGTH_SHORT).show();
                }
               else {
                    text_view.setText("Hello!" + " " + name);
                    controllerclass.nextbtncall(list, index);
                }

                /*Toast.makeText(MainActivity.this, "MainActivity.",Toast.LENGTH_LONG).show();
                    if(index < list.size()) {
                        model = list.get(index);

                        setAllData();
                        resetColor();
                    }
                    else{
                        Submit_Clear();
                    }

                 */
            }
        });

        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                flag = 1;
                //Toast.makeText(MainActivity.this, "MainActivity.",Toast.LENGTH_LONG).show();
                result.clear();
                Intent intent=new Intent(MainActivity.this,MainActivity.class);
                startActivity(intent);

            }
        });

    }

    protected void onResume() {
        // call the superclass method first
        super.onResume();
        Toast.makeText(MainActivity.this, "Main Activity"+getLifecycle().getCurrentState().toString(),Toast.LENGTH_SHORT).show();

        // save the note's current draft, because the activity is stopping
        // and we want to be sure the current note progress isn't lost.
    }
    protected void onPause() {
        // call the superclass method first
        super.onPause();
        Toast.makeText(MainActivity.this, "Pause",Toast.LENGTH_SHORT).show();

        // save the note's current draft, because the activity is stopping
        // and we want to be sure the current note progress isn't lost.
    }

    protected void onStart() {
        // call the superclass method first
        super.onStart();
        Toast.makeText(MainActivity.this, "Main Activity"+getLifecycle().getCurrentState().toString(),Toast.LENGTH_SHORT).show();

        // save the note's current draft, because the activity is stopping
        // and we want to be sure the current note progress isn't lost.
    }
    protected void onRestart() {
        // call the superclass method first
        super.onRestart();
        Toast.makeText(MainActivity.this, "Main Activity"+getLifecycle().getCurrentState().toString(),Toast.LENGTH_SHORT).show();

        // save the note's current draft, because the activity is stopping
        // and we want to be sure the current note progress isn't lost.
    }

    protected void onStop() {
        // call the superclass method first
        super.onStop();
        Toast.makeText(MainActivity.this, "Main Activity"+getLifecycle().getCurrentState().toString(),Toast.LENGTH_SHORT).show();

        // save the note's current draft, because the activity is stopping
        // and we want to be sure the current note progress isn't lost.
    }

    protected void onSaveInstanceState(final Bundle savedInstanceState)
    {

        //text_view = (TextView)  findViewById(R.id.textView);
        String n = (String) text_view.getText();
        Log.i(TAG, "onSaveInstanceState");
        savedInstanceState.putInt("index", index);
        savedInstanceState.putInt("cindex", currentIndex);
        savedInstanceState.putStringArrayList("result", result);
        savedInstanceState.putInt("yes", yes);
        savedInstanceState.putInt("flag",flag);
        savedInstanceState.putString("text_view",n);



        super.onSaveInstanceState(savedInstanceState);

    }

    protected void onRestoreInstanceState(final Bundle savedInstanceState)
    {
        super.onRestoreInstanceState(savedInstanceState);
        index = savedInstanceState.getInt("index");
        result = savedInstanceState.getStringArrayList("result");
        yes = savedInstanceState.getInt("yes");
        currentIndex = savedInstanceState.getInt("cindex");
        flag = savedInstanceState.getInt("flag");
        name = savedInstanceState.getString("text_view");

    }




    private void setAllData() {
        //clearBtn.setVisibility(View.INVISIBLE);

        controllerclass.setAllDatacall(flag);
       /* if(flag == 1)
        {
            editText.setVisibility(View.INVISIBLE);

        }

        Text_question.setText(model.getQuestion());*/

    }

    private void Hooks() {
        Text_question=findViewById(R.id.question);
        text_view = (TextView)  findViewById(R.id.textView);
        //ext_yesBtn=findViewById(R.id.yesBtn);
        //xt_noBtn=findViewById(R.id.noBtn);

        //ard_yesBtn=findViewById(R.id.Card_yesBtn);
        //rd_noBtn=findViewById(R.id.Card_noBtn);
        clearBtn = findViewById(R.id.clearbtn);
        editText  = (EditText)findViewById(R.id.editname) ;
        nextBtn=findViewById(R.id.nextBtn);
        yesBtn=findViewById(R.id.yesBtn);
        noBtn=findViewById(R.id.noBtn);
    }
    /*public void Yes(){
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(index<list.size()-1){
                    yes++;
                    index++;
                    //setAllData();
                    resetColor();
                } else{
                    Submit_Clear();
                }
            }
        });

    }*/
    public void Submit_Clear() {
       //controllerclass.Submit_ClearCall(result,yes,name);
        Intent intent=new Intent(MainActivity.this,MainActivity2.class);
        intent.putExtra("keyname", result);
        intent.putExtra("datacount", yes);
        intent.putExtra("dataname", name);

        startActivity(intent);

    }
    /*public void No(){
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(index<list.size()-1){
                    index++;
                    model=list.get(index);
                    setAllData();
                    resetColor();
                } else{
                    Submit_Clear();
                }
            }
        });

    }





    public void enableButton(){
        yesBtn.setClickable(true);
        noBtn.setClickable(true);
    }
    public void disableButton(){
        yesBtn.setClickable(false);
        noBtn.setClickable(false);
    }
    public void OptionAClick(View view) {
        disableButton();
        nextBtn.setClickable(true);
        card_yesBtn.setCardBackgroundColor(getResources().getColor(R.color.teal_200));
        if (index < list.size() - 1) {
            Yes();
        } else {
            Submit_Clear();
        }
    }
    public void OptionBClick(View view){
        disableButton();
        nextBtn.setClickable(true);
        card_noBtn.setCardBackgroundColor(getResources().getColor(R.color.purple_700));
        if(index<list.size()-1){
            No();
        }
        else{
            Submit_Clear();
        }
    }*/


    private void resetColor() {
        controllerclass.resetColorCall();
       // yesBtn.setBackgroundColor(getResources().getColor(R.color.purple_200));
        //noBtn.setBackgroundColor(getResources().getColor(R.color.purple_200));
    }
}