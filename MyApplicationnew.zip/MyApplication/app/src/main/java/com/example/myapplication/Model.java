package com.example.myapplication;

public class Model {
    String Question;


    public Model(String question){
        Question = question;


    }

    public String getQuestion() {
        return Question;
    }

    public void setQuestion(String question) {
        Question = question;
    }

}
