package com.example.myapplication;

import android.content.Intent;
import android.view.View;

import java.util.ArrayList;

public class Modelclass {

    Controllerclass controllerclass;

    public Modelclass(Controllerclass controllerclass) {
        this.controllerclass = controllerclass;
    }


    public void testcall(ArrayList<String> result, int yes, int index) {

        result.add("Yes");

        yes = yes + 1;
        index = index + 1;
        this.controllerclass.yesbutton(result, yes, index);

    }

    public void Nobtncall(ArrayList<String> result, int index) {
        result.add("No");

        index = index + 1;

        this.controllerclass.nobutton(result, index);
    }

    public void nextbtncall(ArrayList<Model> list, int index) {
        int count = 0;
        if (index < list.size()) {
            count = 1;
        }

        this.controllerclass.nextbutton(list, index, count);
    }

    /*public void Submit_Clear(ArrayList<String> result, int yes, String name){
        Intent intent=new Intent(MainActivity.this,MainActivity2.class);
        intent.putExtra("keyname", result);
        intent.putExtra("datacount", yes);
        intent.putExtra("dataname", name);

        startActivity(intent);
    }*/

    public void activity2call(int count){
        int test = 0;
        if (count > 3) {
            test = 1;
        }
        this.controllerclass.activity2(test);
    }
}
