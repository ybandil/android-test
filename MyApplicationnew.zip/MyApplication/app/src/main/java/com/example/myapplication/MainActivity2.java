package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {

    TextView textName;
    TextView ans;
    String jk;
    Button bb;
    ArrayList<String> symp;
    TableLayout tab;
    Controllerclass controllerclass;


    int count = 0;
    public static ArrayList<String> l;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Toast.makeText(MainActivity2.this, "Main Activity 2"+getLifecycle().getCurrentState().toString(),Toast.LENGTH_SHORT).show();
        l = new ArrayList<>();
        controllerclass= new Controllerclass(this);
        symp = new ArrayList<>();
        symp.add("Fever1");
        symp.add("Cough2");
        symp.add("Cold3");
        symp.add("Fever4");
        symp.add("Fever5");
        symp.add("Fever6");
        symp.add("Fever7");

        tab = (TableLayout)  findViewById(R.id.table1);

        l = getIntent ().getStringArrayListExtra("keyname");
        //textName = (TextView) findViewById(R.id.textName);
        bb  = (Button) findViewById(R.id.buttontest);
        ans = (TextView) findViewById(R.id.textans);
        count = getIntent ().getIntExtra("datacount", 0);
        //textName.setText(l.get(0));
        for(int i =0;i<symp.size();i++) {
            TableRow tr =  new TableRow(this);
            TextView c1 = new TextView(this);
            c1.setTextSize(24);

            c1.setText(symp.get(i));

            TextView c2 = new TextView(this);
            c2.setTextSize(24);
            c2.setPadding(40,0,0,0);
            c2.setText(String.valueOf(l.get(i)));
            tr.addView(c1);
            tr.addView(c2);
            tab.addView(tr);

        }
          ans.setVisibility(View.INVISIBLE);
        bb.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                jk = getIntent ().getStringExtra("dataname");
                controllerclass.activity2function(count);
               /* ans.setVisibility(View.VISIBLE);

                 if(count > 3)
                 {
                     ans.setText(jk+ " You should go for RT-PCR test");
                 }else{
                     ans.setText(jk+ " You NEED NOT TO GO FOR RT-PCR test");
                 }*/
                 //replacefragment(new BlankFragment());
                //Intent intent = new Intent(MainActivity2.this, MainActivity.class);

                //startActivity(intent);

            }

        });
    }

   /* private void replacefragment(BlankFragment blankFragment, ArrayList<String> mm) {

        //BlankFragment blankFragment1 = new BlankFragment();
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        Bundle data = new Bundle();
        data.putStringArrayList("kl", mm);
        blankFragment.setArguments(data);
        fragmentTransaction.replace(R.id.framel, blankFragment);
        fragmentTransaction.commit();
    }*/
}