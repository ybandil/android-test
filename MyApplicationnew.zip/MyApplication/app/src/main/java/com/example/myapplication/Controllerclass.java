package com.example.myapplication;

import android.content.Intent;
import android.graphics.Color;
import android.view.View;

import java.util.ArrayList;

public class Controllerclass {
    Modelclass modelclass;
    MainActivity mainActivity;
    MainActivity2 mainActivity2;

    public Controllerclass(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
        modelclass = new Modelclass(this);
    }
    public Controllerclass(MainActivity2 mainActivity2) {
        this.mainActivity2 = mainActivity2;
        modelclass = new Modelclass(this);
    }

    public void testcall(ArrayList<String> result, int yes, int index) {
        modelclass.testcall(result, yes, index);
    }

    public void yesbutton(ArrayList<String> result, int yes, int index) {
        this.mainActivity.text_view.setText("Hello!" + " " + this.mainActivity.name);
        this.mainActivity.index = index;

        this.mainActivity.yesBtn.setBackgroundColor(this.mainActivity.getResources().getColor(R.color.teal_200));
        if (this.mainActivity.index == this.mainActivity.list.size()) {
            this.mainActivity.clearBtn.setVisibility(View.VISIBLE);
        }
        this.mainActivity.result = result;
        this.mainActivity.yes = yes;
        this.mainActivity.currentIndex  = 1;
    }

    public void Nobtncall(ArrayList<String> result, int index) {
        modelclass.Nobtncall(result, index);
    }

    public void nobutton(ArrayList<String> result, int index) {
        this.mainActivity.text_view.setText("Hello!" + " " + this.mainActivity.name);
        this.mainActivity.index = index;
        this.mainActivity.noBtn.setBackgroundColor(this.mainActivity.getResources().getColor(R.color.teal_200));
        if (this.mainActivity.index == this.mainActivity.list.size()) {
            this.mainActivity.clearBtn.setVisibility(View.VISIBLE);
        }
        this.mainActivity.result = result;
        this.mainActivity.currentIndex  = 2;
    }

    public void nextbtncall(ArrayList<Model> list, int index) {
        modelclass.nextbtncall(list, index);
    }

    public void nextbutton(ArrayList<Model> list, int index, int count) {
        if (count == 1) {
            this.mainActivity.model = list.get(index);

            setAllDatacall(this.mainActivity.flag);
            resetColorCall();
        }
        else{
            this.mainActivity.Submit_Clear();
        }

    }
    /*public void Submit_ClearCall(ArrayList<String> result, int yes , String name) {
        modelclass.Submit_Clear(result,yes,name);
    }

     */

    public void setAllDatacall(int flag) {
        //modelclass.setAllDatacall(list, index);
        this.mainActivity.nextBtn.setEnabled(false);
        this.mainActivity.currentIndex = 0;
        this.mainActivity.check = 0;
        this.mainActivity.nextBtn.setBackgroundColor(Color.rgb(200, 200, 200));
        if (this.mainActivity.flag == 1) {
            this.mainActivity.editText.setVisibility(View.INVISIBLE);

        }


        this.mainActivity.Text_question.setText(this.mainActivity.model.getQuestion());
    }

    public void resetColorCall() {
        this.mainActivity.yesBtn.setBackgroundColor(this.mainActivity.getResources().getColor(R.color.purple_200));
        this.mainActivity.noBtn.setBackgroundColor(this.mainActivity.getResources().getColor(R.color.purple_200));

    }
    public void activity2function(int count){
        modelclass.activity2call(count);
    }
    public void activity2(int test){
        this.mainActivity2.ans.setVisibility(View.VISIBLE);
        if(test==1){
           this.mainActivity2.ans.setText(this.mainActivity2.jk+ " You should go for RT-PCR test");
        }else{
            this.mainActivity2.ans.setText(this.mainActivity2.jk+ " You NEED NOT TO GO FOR RT-PCR test");
        }
    }

}
