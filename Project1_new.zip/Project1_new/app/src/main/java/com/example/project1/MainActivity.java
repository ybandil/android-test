package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
//port android.os.Handler;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    public static ArrayList<Model>list;
    List<Model> allQuestionsList;
    int yes=0;
    int index=0;
    LinearLayout nextBtn;
    LinearLayout noBtn;
    LinearLayout yesBtn;
    Model model;
    TextView Text_question,Text_yesBtn,Text_noBtn;
    CardView card_yesBtn,card_noBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); Hooks();
        list=new ArrayList<>();

        list.add(new Model("Do you have fever?"));
        list.add(new Model("Do you have cough?"));
        list.add(new Model("Do you have Cold?"));
        list.add(new Model("Do you have fever?"));
        list.add(new Model("Do you have fever?"));
        list.add(new Model("Do you have fever?"));
        list.add(new Model("Do you have fever?"));
        allQuestionsList= list;
        Collections.shuffle(allQuestionsList);
        model=list.get(index);
        setAllData();
        nextBtn.setClickable(false);

    }

    private void setAllData() {
        Text_question.setText(model.getQuestion());
    }
    public void Yes(){
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(index<list.size()-1){
                    yes++;
                    index++;
                    model=list.get(index);
                    setAllData();
                    resetColor();
                } else{
                    Submit_Clear();
                }
            }
        });

    }
    public void No(){
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(index<list.size()-1){
                    index++;
                    model=list.get(index);
                    setAllData();
                    resetColor();
                } else{
                    Submit_Clear();
                }
            }
        });

    }


    private void Hooks() {
        Text_question=findViewById(R.id.card_question);
        //ext_yesBtn=findViewById(R.id.yesBtn);
        //xt_noBtn=findViewById(R.id.noBtn);

        //ard_yesBtn=findViewById(R.id.Card_yesBtn);
        //rd_noBtn=findViewById(R.id.Card_noBtn);
        nextBtn=findViewById(R.id.nextBtn);
        yesBtn=findViewById(R.id.yesBtn);
        noBtn=findViewById(R.id.noBtn);
    }

    private void Submit_Clear() {
        Intent intent=new Intent(MainActivity.this,SecondActivity.class);
        startActivity(intent);

    }
    public void enableButton(){
        yesBtn.setClickable(true);
        noBtn.setClickable(true);
    }
    public void disableButton(){
        yesBtn.setClickable(false);
        noBtn.setClickable(false);
    }
    public void OptionAClick(View view) {
        disableButton();
        nextBtn.setClickable(true);
        card_yesBtn.setCardBackgroundColor(getResources().getColor(R.color.green));
        if (index < list.size() - 1) {
            Yes();
        } else {
            Submit_Clear();
        }
    }
    public void OptionBClick(View view){
        disableButton();
        nextBtn.setClickable(true);
        card_noBtn.setCardBackgroundColor(getResources().getColor(R.color.green));
        if(index<list.size()-1){
            No();
        }
        else{
            Submit_Clear();
        }
    }
    private void resetColor() {
        yesBtn.setBackgroundColor(getResources().getColor(R.color.white));
        noBtn.setBackgroundColor(getResources().getColor(R.color.white));
    }
}