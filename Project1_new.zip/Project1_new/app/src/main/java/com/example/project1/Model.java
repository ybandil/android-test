package com.example.project1;

public class Model {
    String Question;


    public Model(String question){
        Question = question;


    }

    public String getQuestion() {
        return Question;
    }

    public void setQuestion(String question) {
        Question = question;
    }

}
